// pages/jh/jh.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:[{
      id: '0',
      title:'计算机系算法讲座',
      description: '这是计算机系算法讲座描述', 
      createtime: '2019-02-12 10:36:02', 
      image:'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKfNticCvATj7fz6OwibqKU7FwJarWMTtc0Qaw0oWnzmrkXOtAQes93pqegPZAIK0ek8m6QhRNfbsxQ/132'
    }, {
        id: '1',
        title: 'bbb',
        description: 'bbb1111',
        createtime: '2019-02-13 10:36:02',         
        image: 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKfNticCvATj7fz6OwibqKU7FwJarWMTtc0Qaw0oWnzmrkXOtAQes93pqegPZAIK0ek8m6QhRNfbsxQ/132'
      }, {
        id: '2',
        title: 'ccc',
        description: 'cccc1111',
        createtime: '2019-02-14 10:36:02',         
        image: 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKfNticCvATj7fz6OwibqKU7FwJarWMTtc0Qaw0oWnzmrkXOtAQes93pqegPZAIK0ek8m6QhRNfbsxQ/132'
      }]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})